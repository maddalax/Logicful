export enum Command {
    UserRegister,
    NormalizeAddress,
    ApplicationError
}