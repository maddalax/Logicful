
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'logicful',
  applicationName: 'logicful',
  appUid: 'Rc2bkGKKDFYqwqtzhg',
  orgUid: 'zlM4wVybqYNk8yHT9w',
  deploymentUid: '457d6408-f9ac-4252-b473-6b699de97bf9',
  serviceName: 'services',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: true,
  accessKey: 'AKs0hHT9xEyVyPIh35GxR6cYS22RWYfrSlXG0CijLo8xM',
  pluginVersion: '3.7.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'services-dev-hello', timeout: 6 };

const studioHandler = (event, context, callback) => {
  console.log('Starting serverless Studio');
  return new Promise((resolve, reject) => {

    // handle callback resolutions since we always return a promise
    let finalized = false;
    const finalize = (error, result, isFromCallback) => {
      if (finalized) { return; }
      finalized = true;
      serverlessSDK
        .publishSync({
          event: "studio.invocationInfo",
          data: {
            functionName: process.env.AWS_LAMBDA_FUNCTION_NAME,
            requestId: context.awsRequestId,
            transactionId: event.requestContext ? event.requestContext.requestId : null,
            response: result,
            error: error
          }
        })
        .catch((err) => {
          console.log('Unable to send response data to Studio', err);
        })
        .finally(() => {
					serverlessSDK.stopDevMode();
					if (isFromCallback) callback(error, result);
          else if (error) reject(error);
          else resolve(result);
        });      
    }

    // Patch context methods
    const contextProxy = new Proxy(context, {
      get: (target, prop) => {
        if (prop === 'done') {
          return (err, res) => {
            finalize(err, res, true)
          };
        } else if (prop === 'succeed') {
          return res => {
            finalize(null, res, true);
          };
        } else if (prop === 'fail') {
          return err => {
            finalize(err, null, true);
          };
        }
        return target[prop];
      },
    });

    // Start dev mode
    serverlessSDK
      .startDevMode(event, context)
      .then(() => {
        try {
          serverlessSDK.publish({
            event: "studio.invocationInfo",
            data: {
              functionName: process.env.AWS_LAMBDA_FUNCTION_NAME,
              requestId: context.awsRequestId,
              transactionId: event.requestContext ? event.requestContext.requestId : null,
              event
            }
          });
        } catch (err) {
          console.log('Unable to send invocation data to Studio', err);
        }
				const userHandler = require('./dist/http/handlers/ValidateAddressHandler.js');
				let result;
        try {
					result = serverlessSDK.handler(userHandler.validateAddress, handlerWrapperArgs)(
						event, contextProxy, (error, result) => finalize(error, result, true)
					);
				} catch (error) {
          console.log('Error invoking wrapped function', error);
					finalize(error, null, true);
					return;
        }
				// if a promise was returned, we need to return the resolved promise
				if (result && typeof result.then === 'function') {
					result.then(res => finalize(null, res), finalize);
				}
      }, (error) => {
				console.error('Unable to start Studio mode', error);
				callback(error);
      });  
  });
};
module.exports.handler = studioHandler