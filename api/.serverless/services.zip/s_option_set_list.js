
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'logicful',
  applicationName: 'logicful',
  appUid: 'Rc2bkGKKDFYqwqtzhg',
  orgUid: 'zlM4wVybqYNk8yHT9w',
  deploymentUid: '1abb5619-85a6-4a86-b39c-5ea3308d1112',
  serviceName: 'services',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.7.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'services-dev-option_set-list', timeout: 45 };

try {
  const userHandler = require('./src/http/handlers/GetOptionSetsHttpHandler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getOptionSets, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}